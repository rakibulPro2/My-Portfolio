# Modern Developer Portfolio Template (React + Vite + Tailwind CSS)

Thank you for purchasing this premium React portfolio template! This project is engineered with Vite for blazing-fast development speeds and styled with Tailwind CSS for clean, modern layouts.

You do **not** need to dig through complex React components to modify the copy. All personal information, projects, and experiences are centralized inside a single file.

---
Projects Live Demo === https://portfolio-ra-11.netlify.app/

## 🚀 Quick Start Guide

Follow these steps to spin up the local development server and preview your portfolio.

### Prerequisites
Ensure you have [Node.js](https://nodejs.org) installed (LTS version recommended).

### Step 1: Install Dependencies
Open your terminal in the project's root directory and run:
```bash
npm install
```

### Step 2: Launch the Vite Local Server
Start your local development environment with:
```bash
npm run dev
```

Your terminal will display a local address, usually **http://localhost:5173**. Open this URL in your web browser to view your live, local site.

---

## ✍️ Customizing Your Information

To swap out the placeholder content for your own personal brand, you only need to modify one single file:

📂 **`src/data/portfolioData.js`**

Open this file in your preferred code editor (like VS Code). You will see structured JavaScript arrays and objects. Simply edit the strings to customize your site:

* **Logo & Navigation Menu:** You can Change portfolio logo, nav menu, menu link (from src/data/portfolioData.jsx #navigation section data )
* **Profile & About:** Change your name, role, headline, Profile image change (from src/data/portfolioData.jsx #hero section Data) & About your journey you can change  (from src/data/portfolioData.jsx #about section Data)
* **Skills Inventory:** Add or remove skills from the tech list to match your exact expertise.
* **Project Showcase:** Insert your custom project titles, descriptions, image paths, live demo URLs, and GitHub code repositories.
* **Work / Experience:** Update your professional milestones, works, or educational degrees with respective dates.

important : if you need change title for this portfolio you need go to index.html and change this title name 

*Tip: Keep your local development server running (`npm run dev`) while editing! The moment you save `portfolioData.js`, the browser will automatically hot-reload with your updates.*

---

## 📦 Production Build & Free Deployment

When your customization is complete, it is time to push your site live to the web.

### Generate the Build Assets
Compile your app into highly optimized, minified static files:
```bash
npm run build
```
This script builds your production assets into a folder named **`dist`** located at your project root.

### Hosting Options (100% Free)
You can launch this web application globally using any of these modern hosting providers:
1. **Netlify:** Log into your Netlify dashboard and simply drag-and-drop the generated `dist` folder into the upload window. 
2. **Vercel:** Install the Vercel CLI or link your project directly to a GitHub repository for automated, hands-free deployments.
3. **GitHub Pages:** Use the static deployment actions to host directly from your public repository code.

---

## 🛠️ Support & Reviews
If you experience any friction or have technical setup questions, please drop a line via the Getly store messaging portal. If this template speeds up your workflow, please take a moment to leave a 5-star review!